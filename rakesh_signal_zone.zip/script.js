let lastPrice = null;
const sound = document.getElementById("alert-sound");

async function fetchPrice() {
  try {
    const res = await fetch('https://api.exchangerate.host/latest?base=EUR&symbols=USD');
    const data = await res.json();
    const currentPrice = data.rates.USD;

    document.getElementById("price").textContent = `Current Price: ${currentPrice.toFixed(5)}`;
    const signalEl = document.getElementById("signal");

    if (lastPrice !== null) {
      if (currentPrice > lastPrice) {
        signalEl.textContent = "🟢 BUY Signal (Market Going Up ⬆️)";
        signalEl.className = "signal green";
        sound.play();
      } else if (currentPrice < lastPrice) {
        signalEl.textContent = "🔴 SELL Signal (Market Going Down ⬇️)";
        signalEl.className = "signal red";
        sound.play();
      } else {
        signalEl.textContent = "➖ No Change";
        signalEl.className = "signal";
      }
    }

    lastPrice = currentPrice;
  } catch (err) {
    document.getElementById("price").textContent = "Error loading price.";
    console.error("Error fetching data:", err);
  }
}

fetchPrice();
setInterval(fetchPrice, 5000);